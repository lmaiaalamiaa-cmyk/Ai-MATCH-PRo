package com.aimatchpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF0B1220)
private val Panel = Color(0xFF172235)
private val Green = Color(0xFF39D98A)
private val Muted = Color(0xFF9AA8BA)

data class Match(
    val league: String,
    val home: String,
    val away: String,
    val score: String,
    val minute: String,
    val live: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AIMatchProApp() }
    }
}

@Composable
fun AIMatchProApp() {
    val matches = listOf(
        Match("الدوري الإنجليزي", "مانشستر سيتي", "ليفربول", "0 - 0", "مباشر", true),
        Match("الدوري الإسباني", "ريال مدريد", "برشلونة", "—", "20:00", false),
        Match("الدوري الإيطالي", "إنتر ميلان", "ميلان", "—", "21:45", false)
    )
    var selectedTab by remember { mutableStateOf("المباريات") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green,
        background = Navy,
        surface = Panel
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("المباريات", "التحليل", "المفضلة").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {},
                            label = { Text(tab) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green,
                                selectedTextColor = Green,
                                indicatorColor = Navy,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("AI MATCH PRO", color = Green, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("كرة القدم • نتائج وتحليلات ذكية", color = Muted, fontSize = 13.sp)
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("مباريات اليوم", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("عالمي", color = Green, fontSize = 13.sp)
                    }
                }
                items(matches) { match -> MatchCard(match) }
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("تحليل الذكاء الاصطناعي", color = Green, fontWeight = FontWeight.Bold)
                            Text(
                                "سيظهر هنا تحليل المباراة واحتمالات الفوز بعد ربط التطبيق بمصدر بيانات كرة القدم ومحرك التوقعات.",
                                color = Color.White,
                                fontSize = 14.sp
                            )
                            Text("تنبيه: التوقعات احتمالية وليست مضمونة.", color = Muted, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Text(
                        "نسخة أولية تجريبية: النتائج المعروضة أمثلة وليست بيانات مباشرة.",
                        color = Muted,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun MatchCard(match: Match) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(match.league, color = Muted, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text(
                    if (match.live) "● مباشر" else match.minute,
                    color = if (match.live) Green else Muted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(match.home, color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Text(match.score, color = Green, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(match.away, color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            }
            HorizontalDivider(color = Color(0xFF2B3B50))
            Text("عرض التحليل  →", color = Green, fontSize = 13.sp)
        }
    }
}
